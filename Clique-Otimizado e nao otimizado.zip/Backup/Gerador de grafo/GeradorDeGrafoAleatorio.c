#include <stdio.h>
#include <stdlib.h>


#define TRUE  1
#define FALSE 0



void grafoAleatorio(){
    FILE * f = fopen("ArquivoGrafo.txt","w");

    if(f == NULL) {
        printf("Arquivo invalido...\n");
        exit(1);
    }


    int tamVertices , totRelacoes;
    printf("Digite quantos vertices tem no seu grafo: ");
    scanf("%d",&tamVertices);
    printf("Informe o total de Relacoes do grafo: ");
    scanf("%d",&totRelacoes);

    fprintf(f,"%d\n",tamVertices);

    int i , j;
    for(i=0 ; i<totRelacoes ; i++){

        int v ,a;
        v = rand() % tamVertices;
        a = rand() % tamVertices;

        fprintf(f , "%d %d\n",v,a);

    }
    fclose(f);
    espera();
}

void espera(){
    printf("\n\tGrafo gerado com sucesso!\npress continue...\n");
    getchar();
    getchar();
}

int main(){

    printf("\n\tGerador de grafo aleatorio\n\n");
    grafoAleatorio();

	return 0;
}

