#include <stdio.h>
#include <stdlib.h>


#define TRUE  1
#define FALSE 0

void espera(){
    printf("\n\tGrafo gerado com sucesso!\npress continue...\n");
    getchar();
    getchar();
}

void grafoAleatorio(){
    FILE * f = fopen("ArquivoGrafo.txt","w");

    if(f == NULL) {
        printf("Arquivo invalido...\n");
        exit(1);
    }


    int tamVertices , totRelacoes;
    printf("Digite quantos vertices tem no seu grafo: ");
    scanf("%d",&tamVertices);
    printf("Informe o total de Relacoes do grafo: ");
    scanf("%d",&totRelacoes);

    fprintf(f,"%d\n",tamVertices);

    int i , j;
    for(i=0 ; i<totRelacoes ; i++){
	int v ,a;        
	do{
            
            v = rand()  % (tamVertices+1) ;
            a = rand()  % (tamVertices+1) ;
            if(v != a)
                fprintf(f , "%d %d\n",v,a);
        }while(v==a);
    }
    fclose(f);
    espera();
}



int main(){

    printf("\n\tGerador de grafo aleatorio\n\n");
    grafoAleatorio();

	return 0;
}

